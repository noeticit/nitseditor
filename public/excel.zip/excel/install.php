<?php

return [
	//Author or Username
	'username' => 'Noetic',
	
    //Plugin name.
    'plugin_name' => 'Nits Editor',

    'menu' => [
		name: 'Excel', 'link' => 'noetic/excel'
	]
];
